﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConsoleApp.Extensions
{
	public static class PathExtension
	{
		public static string CombinePath(string path1, string path2)
		{
			return CombinePath(path1, path2, string.Empty);
		}

		public static string CombinePath(string path1, string path2, string path3)
		{
			return Path.Combine(path1, path2, path3);
		}
	}
}
