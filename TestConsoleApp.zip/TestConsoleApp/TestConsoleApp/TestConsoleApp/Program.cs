using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using TestConsoleApp.Extensions;
using TestConsoleApp.Services;

namespace TestConsoleApp
{
	class Program
	{
		static void Main(string[] args)
		{
			string combinedLettersFolderPath = ConfigurationManager.AppSettings["CombinedLettersFolder"];

			if (Directory.Exists(combinedLettersFolderPath))
			{
				string inputFolderPath =
					PathExtension.CombinePath(combinedLettersFolderPath, "Input");

				string outputFolderPath =
					PathExtension.CombinePath(combinedLettersFolderPath, "Output");

				string archiveFolderPath =
					PathExtension.CombinePath(combinedLettersFolderPath, "Archive");

				string admissionFolderPath =
					PathExtension.CombinePath(inputFolderPath, "Admission");
				
				string scholarshipFolderPath =
					PathExtension.CombinePath(inputFolderPath, "Scholarship");

				IEnumerable<string> admissionFolderPathSubDirectories =
					Directory.GetDirectories(admissionFolderPath)
					.Select(Path.GetFileName);
				
				IEnumerable<string> scholrashipFolderPathSubDirectories =
					Directory.GetDirectories(scholarshipFolderPath)
					.Select(Path.GetFileName);

				var result =
					admissionFolderPathSubDirectories.Intersect(scholrashipFolderPathSubDirectories);

				foreach (var item in result)
				{
					IEnumerable<string> admissionFiles =
						Directory.GetFiles(Path.Combine(admissionFolderPath, item))
						.Select(Path.GetFileNameWithoutExtension)
						.Select(fileName => fileName.Replace("Admission-", string.Empty));

					IEnumerable<string> scholarshipFiles =
						Directory.GetFiles(Path.Combine(scholarshipFolderPath, item))
						.Select(Path.GetFileNameWithoutExtension)
						.Select(fileName => fileName.Replace("Scholarship-", string.Empty)); ;

					var resultFiles =
						admissionFiles
						.Intersect(scholarshipFiles);


					if (resultFiles.Any())
					{
						if (Directory.CreateDirectory(PathExtension.CombinePath(outputFolderPath, item)) != null &&
							Directory.CreateDirectory(PathExtension.CombinePath(archiveFolderPath, item)) != null)
						{
							ILetterService letterService = new LetterService();

							foreach (string fileName in resultFiles)
							{
								string file1 = 
									PathExtension.CombinePath(admissionFolderPath, item, string.Format("Admission-{0}.txt", fileName));

								string file2 = 
									PathExtension.CombinePath(scholarshipFolderPath, item, string.Format("Scholarship-{0}.txt", fileName));

								letterService.CombineTwoLetters(
									file1, 
									file2,
									PathExtension.CombinePath(outputFolderPath, item, string.Format("{0}.txt", fileName)));

								File.Move(
									file1, 
									PathExtension.CombinePath(archiveFolderPath, item, string.Format("Admission-{0}.txt", fileName)));

								File.Move(
									file2, 
									PathExtension.CombinePath(archiveFolderPath, item, string.Format("Scholarship-{0}.txt", fileName)));
							}
						}

						CreateReport(
							resultFiles, 
							item,
							PathExtension.CombinePath(outputFolderPath, item, "Report.txt"));
					}

				}

			}		

			Console.Read();
		}

		public static void CreateReport(IEnumerable<string> reportFiles, string reportDate, string reportFileName)
		{
			StringBuilder stringBuilder = new StringBuilder();
			DateTime reportDateTime = DateTime.ParseExact(reportDate, "yyyyMMdd", CultureInfo.InvariantCulture);
			stringBuilder.AppendLine(reportDateTime.ToString("MM-dd-yyyy") + " Report");
			stringBuilder.AppendLine("-----------------------------------");
			stringBuilder.AppendLine();
			stringBuilder.AppendLine("Number of Combined Letters: " + reportFiles.Count());
			foreach (string item in reportFiles)
				stringBuilder.AppendLine("\t" + item);

			using (StreamWriter writer = File.CreateText(reportFileName))
			{
				writer.WriteLine(stringBuilder.ToString());
			}
		}
	}
}
