﻿using System.IO;

namespace TestConsoleApp.Services
{
	public class LetterService : ILetterService
	{
		public void CombineTwoLetters(string inputFile1, string inputFile2, string resultFile)
		{
			using (StreamWriter writer = File.CreateText(resultFile))
			{
				using (StreamReader reader1 = File.OpenText(inputFile1))
				{
					using (StreamReader reader2 = File.OpenText(inputFile2))
					{
						string line1 = null;
						string line2 = null;
						while ((line1 = reader1.ReadLine()) != null)
						{
							writer.WriteLine(line1);
							line2 = reader2.ReadLine();
							if (line2 != null)
								writer.WriteLine(line2);
						}
					}
				}
			}
		}
	}
}
